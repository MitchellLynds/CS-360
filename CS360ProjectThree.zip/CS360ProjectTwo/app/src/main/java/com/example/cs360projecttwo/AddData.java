package com.example.cs360projecttwo;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AddData extends AppCompatActivity {

    // creating variables for our edittext, button and dbhandler
    private EditText dateEdt, weightEdt;
    private Button addWeightBtn;
    private DBHandler dbHandler;
    private SettingsDBHandler settingHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_data);

        // initializing all our variables.
        dateEdt = findViewById(R.id.idEdtDate);
        weightEdt = findViewById(R.id.idEdtWeight);
        addWeightBtn = findViewById(R.id.idBtnAddWeight);

        // creating a new dbhandler class
        // and passing our context to it.
        dbHandler = new DBHandler(AddData.this);
        settingHandler = new SettingsDBHandler(AddData.this);

        // below line is to add on click listener for our add course button.
        addWeightBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // below line is to get data from all edit text fields.
                String userDate = dateEdt.getText().toString();
                String userWeight = weightEdt.getText().toString();

                // validating if the text fields are empty or not.
                if (userDate.isEmpty() && userWeight.isEmpty()) {
                    Toast.makeText(AddData.this, "Please enter all the data..", Toast.LENGTH_SHORT).show();
                    return;
                }

                // on below line we are calling a method to add new
                // course to sqlite data and pass all our values to it.
                dbHandler.addNewWeight(userDate, userWeight);
                Boolean goalMessage = settingHandler.checkUserPermission(userWeight);

                // after adding the data we are displaying a toast message.
                if (goalMessage) {
                    Toast.makeText(AddData.this, "Goal Reached.", Toast.LENGTH_SHORT).show();
                }
                dateEdt.setText("");
                weightEdt.setText("");

                Intent i = new Intent(AddData.this, GridDisplay.class);
                startActivity(i);
            }
        });
    }
}
