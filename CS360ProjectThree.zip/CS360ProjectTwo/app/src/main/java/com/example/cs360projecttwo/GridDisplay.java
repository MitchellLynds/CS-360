package com.example.cs360projecttwo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class GridDisplay extends AppCompatActivity {

    // creating variables for our array list,
    // dbhandler, adapter and recycler view.
    private ArrayList<WeightModal> weightModalArrayList;
    private DBHandler dbHandler;
    private WeightRVAdapter weightRVAdapter;
    private RecyclerView weightsRV;
    private Button addBtn, updateBtn, settingBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grid_display);

        // initializing our all variables.
        weightModalArrayList = new ArrayList<>();
        dbHandler = new DBHandler(GridDisplay.this);

        // getting our course array
        // list from db handler class.
        weightModalArrayList = dbHandler.readWeights();

        // on below line passing our array lost to our adapter class.
        weightRVAdapter = new WeightRVAdapter(weightModalArrayList, GridDisplay.this);
        weightsRV = findViewById(R.id.idRVWeights);

        // setting layout manager for our recycler view.
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(GridDisplay.this, RecyclerView.VERTICAL, false);
        weightsRV.setLayoutManager(linearLayoutManager);

        // setting our adapter to recycler view.
        weightsRV.setAdapter(weightRVAdapter);

        addBtn = findViewById(R.id.idBtnAddWeight);
        updateBtn = findViewById(R.id.idBtnUpdateWeight);
        settingBtn = findViewById(R.id.idBtnSettings);

        addBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(GridDisplay.this, AddData.class);

                startActivity(intent);

            }
        });
        updateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(GridDisplay.this, UpdateWeightActivity.class);

                startActivity(intent);

            }
        });
        settingBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(GridDisplay.this, UserPermissions.class);

                startActivity(intent);

            }
        });
    }
}
