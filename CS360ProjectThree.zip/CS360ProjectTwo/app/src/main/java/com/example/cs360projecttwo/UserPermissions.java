package com.example.cs360projecttwo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

public class UserPermissions extends AppCompatActivity {

    private EditText goalEdt;
    private Button setGoalBtn;
    private Switch allowSwitch;
    private SettingsDBHandler dbHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_permissions);

        // initializing all our variables.
        goalEdt = findViewById(R.id.idGoalWeightEdt);
        setGoalBtn = findViewById(R.id.idBtnSetGoal);
        allowSwitch = findViewById(R.id.idSwitchAllow);

        dbHandler = new SettingsDBHandler(UserPermissions.this);

        setGoalBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // below line is to get data from all edit text fields.
                String userGoal = goalEdt.getText().toString();
                Boolean userPermission = allowSwitch.isChecked();
                // validating if the text fields are empty or not.
                if (userGoal.isEmpty()) {
                    Toast.makeText(UserPermissions.this, "Please enter all the data..", Toast.LENGTH_SHORT).show();
                    return;
                }

                // on below line we are calling a method to add new
                // course to sqlite data and pass all our values to it.
                dbHandler.setGoal(userGoal, userPermission);

                // after adding the data we are displaying a toast message.
                Toast.makeText(UserPermissions.this, "Goal has been set.", Toast.LENGTH_SHORT).show();
                goalEdt.setText("");

                Intent i = new Intent(UserPermissions.this, GridDisplay.class);
                startActivity(i);
            }
        });

    }
}