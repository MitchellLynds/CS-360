package com.example.cs360projecttwo;

public class WeightModal {
    // variables
    private String date;
    private String weight;

    private int id;

    // creating getter and setter methods
    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getWeight() {
        return weight;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    // constructor
    public WeightModal(String date, String weight) {
        this.weight = date;
        this.date = weight;
    }
}
