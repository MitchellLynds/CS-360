package com.example.cs360projecttwo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {
    // creating variables for our edittext, button and dbhandler
    private EditText usernameEdt, passwordEdt;
    private Button loginBtn, registerBtn;
    private LoginDBHandler dbHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // initializing all our variables.
        usernameEdt = findViewById(R.id.idEdtUsername);
        passwordEdt = findViewById(R.id.idEdtPassword);
        loginBtn = findViewById(R.id.idLoginBtn);
        registerBtn = findViewById(R.id.idRegisterBtn);

        // creating a new dbhandler class
        // and passing our context to it.
        dbHandler = new LoginDBHandler(LoginActivity.this);

        // below line is to add on click listener for our add course button.

        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // below line is to get data from all edit text fields.
                String username = usernameEdt.getText().toString();
                String password = passwordEdt.getText().toString();

                // validating if the text fields are empty or not.
                if (username.isEmpty() && password.isEmpty()) {
                    Toast.makeText(LoginActivity.this, "Please enter all the data..", Toast.LENGTH_SHORT).show();
                    return;
                }

                // on below line we are calling a method to add new
                // course to sqlite data and pass all our values to it.
                boolean success = dbHandler.checkUserExist(username, password);

                // after adding the data we are displaying a toast message.
                if(success){
                    Intent intent = new Intent(LoginActivity.this, GridDisplay.class);
                    intent.putExtra("username", usernameEdt.getText().toString());
                    startActivity(intent);
                } else {
                    passwordEdt.setText(null);
                    Toast.makeText(LoginActivity.this, "Login failed. Invalid username or password.", Toast.LENGTH_SHORT).show();
                }

            }
        });

        registerBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // below line is to get data from all edit text fields.
                String username = usernameEdt.getText().toString();
                String password = passwordEdt.getText().toString();

                // validating if the text fields are empty or not.
                if (username.isEmpty() && password.isEmpty()) {
                    Toast.makeText(LoginActivity.this, "Please enter all the data..", Toast.LENGTH_SHORT).show();
                    return;
                }

                // on below line we are calling a method to add new
                // course to sqlite data and pass all our values to it.
                dbHandler.addNewUser(username, password);

                // after adding the data we are displaying a toast message.
                Toast.makeText(LoginActivity.this, "Weight has been added.", Toast.LENGTH_SHORT).show();
                usernameEdt.setText("");
                passwordEdt.setText("");
            }
        });





    }
}