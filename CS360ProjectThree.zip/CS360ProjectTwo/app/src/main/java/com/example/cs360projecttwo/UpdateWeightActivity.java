package com.example.cs360projecttwo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class UpdateWeightActivity extends AppCompatActivity {

    // variables for our edit text, button, strings and dbhandler class.
    private EditText dateEdt, weightEdt;
    private Button updateWeightBtn, deleteWeightBtn;
    private DBHandler dbHandler;
    String date, weight;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_weight);

        // initializing all our variables.
        dateEdt = findViewById(R.id.idEdtDate);
        weightEdt = findViewById(R.id.idEdtWeight);
        updateWeightBtn = findViewById(R.id.idBtnUpdateWeight);
        deleteWeightBtn = findViewById(R.id.idBtnDelete);

        // on below line we are initialing our dbhandler class.
        dbHandler = new DBHandler(UpdateWeightActivity.this);

        // on below lines we are getting data which
        // we passed in our adapter class.
        date = getIntent().getStringExtra("date");
        weight = getIntent().getStringExtra("weight");

        // setting data to edit text
        // of our update activity.
        dateEdt.setText(date);
        weightEdt.setText(weight);

        // adding on click listener to our update weight button.
        updateWeightBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // inside this method we are calling an update weight
                // method and passing all our edit text values.
                dbHandler.updateWeight(dateEdt.getText().toString(), dateEdt.getText().toString(), weightEdt.getText().toString());

                // displaying a toast message that our weight has been updated.
                Toast.makeText(UpdateWeightActivity.this, "Weight Updated..", Toast.LENGTH_SHORT).show();

                // launching our main activity.
                Intent i = new Intent(UpdateWeightActivity.this, GridDisplay.class);
                startActivity(i);
            }
        });

        // adding on click listener for delete button to delete our weight.
        deleteWeightBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // calling a method to delete our course.
                dbHandler.deleteWeight(dateEdt.getText().toString());
                Toast.makeText(UpdateWeightActivity.this, "Deleted the weight", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(UpdateWeightActivity.this, GridDisplay.class);
                startActivity(i);
            }
        });

    }
}
